#include <stdio.h>

int main(int argc, char const *argv[])
{
	fork();
	while(1)pause();
	return 0;
}