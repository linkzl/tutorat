#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char const *argv[])
{
	char value;
	int gentillesse=0;
	while (1)
	{
		scanf("%s",&value);
		if (strcmp(&value,"+"))
		{
			gentillesse++;
		}
		if (strcmp(&value,"-"))
		{
			gentillesse--;
		}
		printf("\n%d\n",gentillesse );
	}
	return 0;
}