import numpy as np



def moindre_carre(X,t):
	return np.dot(np.linalg.inv(np.dot(np.transpose(X),X)),np.dot(np.transpose(X),t))


def main():
	X =np.loadtxt('iris.data',usecols=(0,1,2,3,4),delimiter=',',dtype=float)
	t = np.loadtxt('iris.data',usecols=(5,),delimiter=',',dtype=int)
	print moindre_carre(X,t)

if __name__ == '__main__':
	main()