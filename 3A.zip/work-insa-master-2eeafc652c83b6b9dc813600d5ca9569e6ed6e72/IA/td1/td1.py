import numpy as np
import random
"""
	Iris-setosa =1
	Iris-virginica =-1
"""

def perceptron(X,Y,w_ini,w,eta,seuil):
	N,D=np.shape(X)
	max_iter=10000
	w=w_ini
	nb_iter=0
	mal_classe=N
	while(mal_classe>seuil) and (nb_iter<max_iter):
		nb_iter=nb_iter+1
		mal_classe=0
		Dw=nb.zeros(D)
		for i in xrange(0,N):
			if (Y[i]*(np.dot(w,X[i,:])+w0)<0):
				mal_classe=mal_classe+1
				Dw=Dw-Y[i]*X[i,:]
				pass
			pass
		w=w-eta*Dw
	return w

def calcul_erreur(X,Y,W,W0):
    N,D=np.shape(X);
    erreur=0; 
    for i in range(0,N):
        h = np.dot(W,X[i,:])+w0
        if h*Y[i]<0:
            erreur=erreur+1
    return erreur/float(N), erreur 

def main():
	X =np.loadtxt('iris_a.txt',usecols=(0,1,2,3),delimiter=',',dtype=float)
	Y = np.loadtxt('iris_a.txt',usecols=(4,),delimiter=',',dtype=int)
	N,D=np.shape(X);
	w_ini=np.random.randn(D)
	w0 = np.random.randn(1)
	eta = 0.01
	seuil = 3
	X_a=X[0:25,:]                
	X_a=np.vstack((X_a,X[50:75,:])) 
	Y1=Y[0:25]                  
	Y1=np.hstack((Y1,Y[50:75]))
	W = perceptron(X_a,Y1,w_ini,w0,eta,seuil)
	X_b=X[26:50,:]             
	X_b=np.vstack((X_b,X[76:100,:]))
	Y2=Y[26:50]                   
	Y2=np.hstack((Y1,Y[76:100])) 
	print calcul_erreur(X_b,Y2,W,w0)




if __name__=='__main__':
	main()

