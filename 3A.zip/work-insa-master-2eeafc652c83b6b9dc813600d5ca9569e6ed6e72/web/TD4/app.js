// Write JavaScript here function somme()
function somme()
{
    var s=0;
    var nombres=document.getElementsByName('nombre');
    for (var i =0; i<nombres.length;i++)
    {
      if (nombres[i].checked)
        s=s+parseInt(nombres[i].value,10);
      }
    alert("la somme vaut " +s) ;
}

function moyenne()
{
    var s=0;
    var a=0;
    var nombres=document.getElementsByName('nombre');
    for (var i =0; i<nombres.length;i++)
    {
      
      if (nombres[i].checked)
      {
        s=s+parseInt(nombres[i].value,10);
        a++;
      }
    }
    alert("la moyenne vaut " +s/(a));
}

function creer(){
  var combien= window.parseInt(document.getElementById('combien').value ) ;
  var i;
  var c=document.getElementById ('c') ;
  for ( i =1; i<=combien; i++)
  {
    c.innerHTML=c.innerHTML+ '<input type ="checkbox" name="nombre"  id ="'+ i + '" value ="'+ i + '"/>' ;
    c.innerHTML=c.innerHTML+ '<label for =" '+ i + ' ">'+ i + '</label>' ;
  }
  c.innerHTML=c.innerHTML+ '<input type ="button" value ="calculer la somme" onclick ="somme();"/>' ;
}
