function inf()
{
  var res = "",at, el, nd, all_attr;
  nd = document.getElementById('ma_div'); //node
  all_attr = nd.attributes;
  for (i = 0; i != all_attr.length; i++)
  {
    at = all_attr[i];
    res += 'ATTR: ' + at.nodeName + ' = "' + at.nodeValue + '"\n';
  }
  var enfants = nd.childNodes;
  for (i = 0; i != enfants.length; i++)
  {
    el = enfants[i];
    res += el.nodeName;
    if (el.nodeType == 3)
      res += ' = "' + el.nodeValue + '"\n';
    else
      res += "--\n";
  }
  resnode = document.createElement('div');
  body = document.getElementsByTagName('body')[0];
  body.appendChild(resnode);
  titlenode = document.createElement('h1');
  titlenode.appendChild(document.createTextNode('Ceci et le contenu de la div'));
  contentnode = document.createElement('pre');
  contentnode.appendChild(document.createTextNode(res));
  resnode.appendChild(titlenode);
  resnode.appendChild(contentnode);
}

function ajouter()
{
  var txt = document.getElementById("ajout");
  if (txt.value!=="")
  {
    var contentnode = document.createElement('li');
    contentnode.innerHTML = txt.value;
    var liste=document.getElementById("courses");
    liste.appendChild(contentnode);
  }
}


function retirer()
{
  var liste=document.getElementById('courses');
  liste.removeChild(liste.lastChild);
}