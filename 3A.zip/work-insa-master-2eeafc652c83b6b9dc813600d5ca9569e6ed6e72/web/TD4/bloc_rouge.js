function animer(e)
{
  var rouge=document.getElementById("carre");
  switch(e.keyCode)
    {
      case 37:
        if (isNaN(parseInt(rouge.style.right,10)))
        {
            rouge.style.right = "550px"; 
        } 
        else
        { 
             before=parseInt(rouge.style.right,10);
             after=before+10;
             rouge.style.right=after;
        } 
        break; 
        
      case 38:
        if (isNaN(parseInt(rouge.style.bottom,10)))
        {
            rouge.style.bottom = "350px";
        }
        else
        {
             before=parseInt(rouge.style.bottom,10);
             after=before+10;
             rouge.style.bottom=after;
        }
        break;
      case 39:
        if (isNaN(parseInt(rouge.style.right,10)))
        {
           rouge.style.right = "550px";
        }
        else
        {
             before=parseInt(rouge.style.right,10);
             after=before-10;
             rouge.style.right=after;
        }
        break;
      case 40:
        if (isNaN(parseInt(rouge.style.bottom,10))) 
        {
            rouge.style.bottom = "350px";
        } 
        else
        {
             before=parseInt(rouge.style.bottom,10);
             after=before-10;
             rouge.style.bottom=after;
        }
        break;
    } 
    
}