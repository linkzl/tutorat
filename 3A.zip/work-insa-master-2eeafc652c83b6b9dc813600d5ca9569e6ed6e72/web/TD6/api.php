
<?php 
include_once'dbconnect.php';
$res = $DBcon->query("SELECT * FROM produit");
$data = array();
while ($productsRow= $res->fetch_assoc()){
  $data[] = $productsRow;
}
$res->free();
$DBcon->close();
echo json_encode($data);
?>