<!DOCTYPE html>
<html>
  <head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <script language="javascript" type="text/javascript" src="jquery-1.9.1.min.js"></script>
  </head>
  <body>

  
  <h2> Client  </h2>
  <h3>Output: </h3>
  <div id="output">dans cet élément, ici,le résultat sera affiché !</div>

  <script id="source" language="javascript" type="text/javascript">

  $(document).ready(function () 
  {
	 $('#output').empty();
    //-----------------------------------------------------------------------
    // 2) Send a http request with AJAX http://api.jquery.com/jQuery.ajax/
    //-----------------------------------------------------------------------
    $.ajax({                                      
      url: 'api.php',                  //the script to call to get data          
      data: "",                        //you can insert url argumnets here to pass to api.php
                                       //for example "id=5&parent=6"
      dataType: 'json',                //data format      
      success: function(rows)          //on recieve of reply
      {
	    
       for (var i in rows)
       {
		//$('#output').append("hell11o");
         var row = rows[i];          

         var id = row["code"];
         var vname = row["nom"];
         $('#output').append("<br/><b>id: </b>"+id+"<b> name: </b>"+vname)
                  .append("");
       } 
     } 
    });
  }); 

  </script>
  </body>
</html>
