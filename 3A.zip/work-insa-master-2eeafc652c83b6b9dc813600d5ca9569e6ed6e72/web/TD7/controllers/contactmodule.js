var myApp = angular.module('ContactModule', []);

myApp.controller('ContactController', ['$scope', function($scope) {
	$scope.contact={
		name: "Louis Boury",
		email: "louis.boury@insa-cvl.fr",
		phone: "0123456789"
	};
	$scope.calculate= function(a,b) {
		return (a+b)*3;
	}
}]);
