function deftitre1()
{
	var id = document.getElementById("titre");
	document.title=id.textContent;
}

function deftitre2()
{
	var id = document.getElementsByTagName("h2")[0];
	document.title=id.textContent;
}

function deftitre3()
{
	var size = document.getElementsByTagName("h2").length;
	var id = document.getElementsByTagName("h2")[size -1];
	if (size==0) {document.title="louis boury"};
	document.title=id.textContent;
}

function deftitre4()
{
	var c = document.getElementsByClassName("firstOrLast");
	var len = c.length;
	if (len%2==0)
	{
		document.title = document.getElementsByClassName("firstOrLast")[0].textContent;
	}
	else if (len==0)
	{
		document.title="louis boury"
	}
	else
	{
		document.title = document.getElementsByClassName("firstOrLast")[len -1].textContent;
	}
}