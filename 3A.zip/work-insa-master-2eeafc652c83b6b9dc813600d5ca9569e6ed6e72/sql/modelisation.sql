#1
create table personne (
	nom varchar(25) not null,
	activite varchar(50),
	sexe varchar(25) not null,
	age integer(3), not null,
	adresse varchar(50),
	email varchar(50) not null,
	primary key(email),
	unique(nom, adresse));

create table groupe (
	description varchar(50),
	nom varchar(25) not null ,
	possesseur varchar(50) not null,
	primary key (nom),
	foreign key (possesseur) references personne(email));

create table est_membre (
	email_membre varchar(50) not null,
	nom_groupe varchar(25) not null,
	primary key (email_membre,nom_groupe),
	foreign key (email_membre) references personne(email),
	foreign key (nom_groupe) references groupe(nom));

create table est_ami (
	email_contact varchar(50) not null ,
	email_contacteur varchar(50) not null,
	primary key (email_contact,email_contacteur),
	foreign key (email_contact) references personne(email),
	foreign key (email_contacteur) references personne(email));

#alter table personne add constraint c_personne_1 primary key (email)
#autre facon de declarer les cles primaire et autres contraintes


